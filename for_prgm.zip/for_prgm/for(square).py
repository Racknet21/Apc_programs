#Write a PYTHON program that prints  1 2 4 8 16 32 … n2

n = int(input("Enter the number of terms: "))

i = 1
value = 1

while i <= n:
    print(value)
    value = value * 2
    i += 1
