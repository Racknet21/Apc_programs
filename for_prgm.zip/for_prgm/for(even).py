#Write a PYTHON program to print the even numbers up to n
n = int(input("Enter the value of n: "))
i = 2
while i <= n:
    print(i)
    i += 2
