#Write a PYTHON program to print the natural numbers up to n
n=int(input("enter number: "))
i=1
for i in range(i,n+1):
    print(i)
