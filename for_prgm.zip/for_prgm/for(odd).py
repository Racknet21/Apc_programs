#Write a PYTHON program to print odd numbers up to n
n = int(input("Enter the value of n: "))
i = 1
while i <= n:
    print(i)
    i += 2
