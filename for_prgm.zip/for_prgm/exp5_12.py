#5
n = int(input("Enter n: "))

total = 1
fact = 1

for i in range(1, n + 1):
    fact = fact * i
    total = total + 1 / fact

print("Sum of series:", total)

#6.
x = float(input("Enter x in radians: "))
n = int(input("Enter number of terms: "))

total = 0

for i in range(n):
    power = 2 * i
    fact = 1

    for j in range(1, power + 1):
        fact = fact * j

    term = (x ** power) / fact

    if i % 2 == 0:
        total = total + term
    else:
        total = total - term

print("Cosine value:", total)


#7.
n = int(input("Enter a number: "))

root = int(n ** 0.5)

if n < 0 or root * root != n or root < 2:
    print("Square root is not a prime number")
else:
    prime = True

    for i in range(2, root):
        if root % i == 0:
            prime = False
            break

    if prime:
        print("Square root is a prime number")
    else:
        print("Square root is not a prime number")


#8.
for i in range(3):
    for j in range(3):
        print(chr(65 + j), end=" ")
    print()


#9.
n = int(input("Enter n: "))

for i in range(1, n + 1):
    for j in range(i):
        print(chr(65 + j), end=" ")
    print()


#10.
n = int(input("Enter n: "))

for i in range(n, 0, -1):
    for j in range(i):
        print(chr(65 + j), end=" ")
    print()


#11.

n = int(input("Enter n: "))

for i in range(1, n + 1):
    for j in range(1, i + 1):
        print(j, end=" ")
    print()

#12.
n = int(input("Enter n: "))

for i in range(1, n + 1):
    for j in range(i):
        print(i, end=" ")
    print()



