#Write a PYTHON program to print Fibonacci series up to n
n=int(input("enter number n: "))
i=0
j=1
sum=1
while(sum<=n):
    print(i)
    c=i+j
    i=j
    j=c
    sum+=1
    
    
