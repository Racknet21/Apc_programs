#Write a PYTHON program to print the multiplication table
num=int(input("enter number: "))
i=1
while(i<=10):
    print(num,"x",i,"=",num*i)
    i+=1
   
