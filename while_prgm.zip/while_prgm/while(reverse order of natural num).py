#Write a PYTHON program to print natural numbers up to n in reverse order.
n=int(input("enter number n:"))
i=n
while(i>=1):
    print(i)
    i-=1
