#Write a PYTHON program to print sum of natural numbers up to n

n=int(input("enter number n: "))
i=1
sum=0
while(i<=n):
    sum=sum+i
    print(i)
    i+=1
    
print("sum:",sum)

 
