#Write a PYTHON program to print sum of odd numbers up to n
n=int(input("enter number n: "))
i=1
sum=0
while(i<=n):
    if(i%2!=0):
        sum=sum+i
        print(i)
    i+=1
print("sum:",sum)
