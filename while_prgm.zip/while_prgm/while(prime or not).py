#Write a PYTHON program to check the entered number is prime or not
n=int(input("enter number: "))
i=2
while(i<n):
    if(n%i==0):
        print("not prime number")
        break
    i+=1
if i==n:
    print("prime number")
    
