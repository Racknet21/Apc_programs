#Write a PYTHON program to print odd numbers up to n
n=int(input("enter number n: "))
i=1
while(i<=n):
    if(i%2!=0):
        print(i)
    i+=1
