#Write a PYTHON program to reverse the given number.
# Program to reverse a given number
n = int(input("Enter a number: "))
reverse = 0
while n > 0:
    digit = n % 10
    reverse = reverse * 10 + digit
    n = n // 10
print("Reversed number =", reverse)
