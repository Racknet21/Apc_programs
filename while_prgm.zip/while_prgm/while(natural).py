#Write a PYTHON program to print the natural numbers up to n
i=1
n=int(input("enter n number: "))
while(i<=n):
    print(i)
    i+=1
