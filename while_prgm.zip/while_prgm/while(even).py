#Write a PYTHON program to print even numbers up to n
n=int(input("enter n number: "))
i=1
while(i<=n):
    if(i%2==0):
        print(i)
    i+=1
   
