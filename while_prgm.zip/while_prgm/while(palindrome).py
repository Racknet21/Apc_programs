#Write a PYTHON program to check the entered  number is palindrome or not
n = int(input("Enter a number: "))
i = n
reverse = 0
while n > 0:
    digit = n % 10
    reverse = reverse * 10 + digit
    n = n // 10
if i == reverse:
    print("Palindrome")
else:
    print("Not Palindrome")
        
