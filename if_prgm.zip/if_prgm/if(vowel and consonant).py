#Write a PYTHON program to check entered character is vowel or consonant.
char=input("enter any character: ")
if char in "aeiouAEIOU":
    print("entered character is vowel")
else:
    print("entered character is consonant")
    
