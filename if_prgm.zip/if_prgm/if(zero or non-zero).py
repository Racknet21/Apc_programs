#Write a PYTHON program that reads a value of n and check the number is zero or non zero value.
n=int(input("enter a number"))
if(n==0):
    print("given number is zero")
else:
    print("given number is nonzero")
