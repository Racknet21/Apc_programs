#A company insures its drivers in the following cases:
#If the driver is married
#If the driver is unmarried, male and above 30 years of age
#If the driver is unmarried, female and above 25 years of age.
#In all the other cases, the driver is not insured. Write a PYTHON program to determine whether the driver is insured or not
status=input("enter the martial status: ")
if(status=="married"):
    print("insured")
else:
    gender=input("enter gender: ")
    age=int(input("enter your age: "))
    if(gender=="male" and age>=30):
        print("insured")
    elif(gender=="female" and age>=25):
        print("insured")
    else:
        print("not insured")
