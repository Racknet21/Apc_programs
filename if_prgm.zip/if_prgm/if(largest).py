#Write a PYTHON program to find a largest of two numbers.
n1=int(input("enter the first number: "))
n2=int(input("enter the second number: "))
if(n1>n2):
    print("the largeset no is: ",n1)
else:
    print("the largeset no is: ",n2)
