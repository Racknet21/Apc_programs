#Write a PYTHON program that reads the number and check the no is positive or negative.
n=int(input("enter the number: "))
if(n>=0):
    print("given number is positive")
else:
    print("given number is negative")
