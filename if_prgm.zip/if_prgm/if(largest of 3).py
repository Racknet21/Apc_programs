#Write a PYTHON program to find largest of three numbers.
num1=int(input("enter first number: "))
num2=int(input("enter second number: "))
num3=int(input("enter third number: "))
if(num1>=num2 and num1>=num3):
    print("the largest number is: ",num1)
elif(num2>=num3):
    print("the largest number is: ",num2)
else:
    print("the largest number is: ",num3)
