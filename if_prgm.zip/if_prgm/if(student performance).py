#Write a PYTHON program to evaluate the student performance
#If % is >=90 then Excellent performance
#If % is >=80 then  Very Good performance
#If % is >=70 then Good performance
#If % is >=60 then average performance
#else Poor performance.

marks=int(input("enter students marks: "))
if(marks>=90):
          print("Excellent Performance")
elif(marks>=80):
          print("Very good Performance")
elif(marks>=70):
          print("good Performance")
elif(marks>=60):
          print("Average Performance")
else:
    print("Poor")
