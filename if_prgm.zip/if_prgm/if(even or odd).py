#Write a PYTHON program to check weather number is even or odd.
num=int(input("enter number: "))
if(num%2==0):
    print("number is even")
else:
    print("number is odd")

    
